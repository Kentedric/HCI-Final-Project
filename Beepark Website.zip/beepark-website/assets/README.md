# Local Assets Folder

Use this folder when you want to replace external CDN links with local files.

Suggested structure:

- `assets/icons/` for icon files (Flaticon license-compliant downloads)
- `assets/images/` for photos/reference images (Pinterest/Unsplash/Pexels with proper rights)

Example file names:

- `assets/icons/logo-beepark.png`
- `assets/icons/icon-qr.png`
- `assets/icons/icon-map-pin.png`
- `assets/icons/icon-wallet.png`
- `assets/images/hero-parking.jpg`
- `assets/images/parking-gate.jpg`
- `assets/images/find-vehicle-map.jpg`

Automatic setup:

1. Download all assets into this folder:
   - `python download-assets.py`
2. Remap all HTML files to local assets:
   - `python use-local-assets.py`

This will place PNG/JPEG assets in separate folders and wire them into the project.
