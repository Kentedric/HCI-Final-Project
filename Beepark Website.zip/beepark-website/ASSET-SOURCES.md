# Beepark Asset Sources (Non-AI)

This website uses real assets from public sources (not AI-generated).

## Pinterest
- UI inspiration:
  - https://www.pinterest.com/search/pins/?q=parking%20app%20ui
- Sample image used:
  - https://i.pinimg.com/564x/7b/37/8a/7b378a4fef35a531fcb021adf50f4c2f.jpg

## Flaticon
- Parking / utility icon search:
  - https://www.flaticon.com/free-icons/parking
- Sample icons used:
  - https://cdn-icons-png.flaticon.com/512/3097/3097144.png
  - https://cdn-icons-png.flaticon.com/512/2972/2972185.png
  - https://cdn-icons-png.flaticon.com/512/854/854878.png
  - https://cdn-icons-png.flaticon.com/512/1792/1792688.png
  - https://cdn-icons-png.flaticon.com/512/3202/3202926.png
  - https://cdn-icons-png.flaticon.com/512/2550/2550205.png
  - https://cdn-icons-png.flaticon.com/512/565/565547.png
  - https://cdn-icons-png.flaticon.com/512/535/535188.png

## Unsplash
- Search:
  - https://unsplash.com/s/photos/parking-lot
- Sample photos used:
  - https://images.unsplash.com/photo-1519583272095-6433daf26b6e
  - https://images.unsplash.com/photo-1621929747188-0b4dc28498d2

## Pexels
- Search:
  - https://www.pexels.com/search/parking/
- Sample photos used:
  - https://images.pexels.com/photos/1004409/pexels-photo-1004409.jpeg
  - https://images.pexels.com/photos/4386321/pexels-photo-4386321.jpeg

## Notes
- Please review each source's license terms before commercial release.
- You can replace CDN links with local files later in `assets/images` and `assets/icons`.
