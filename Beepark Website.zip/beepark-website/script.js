const slotGrid = document.getElementById("slotGrid");
const selectedSlotEl = document.getElementById("selectedSlot");
const bookingResult = document.getElementById("bookingResult");
const modal = document.getElementById("bookingModal");
const modalText = document.getElementById("modalText");
const closeModalBtn = document.getElementById("closeModal");

const confirmBookingBtn = document.getElementById("confirmBooking");
const plateInput = document.getElementById("plateInput");
const vehicleType = document.getElementById("vehicleType");
const durationInput = document.getElementById("duration");

const scanBtn = document.getElementById("scanBtn");
const qrInput = document.getElementById("qrInput");
const scanResult = document.getElementById("scanResult");
const parkingStatus = document.getElementById("parkingStatus");

const payNowBtn = document.getElementById("payNowBtn");
const payResult = document.getElementById("payResult");

const navBtn = document.getElementById("navBtn");
const navResult = document.getElementById("navResult");

const menuToggle = document.getElementById("menuToggle");
const menu = document.querySelector(".menu");
const globalStatus = document.getElementById("globalStatus");

const slotState = [];
let selectedSlot = null;

const STORAGE_KEY = "beepark_booking";
const STEP_KEY = "beepark_step";
const STEPS = { BOOKED: 1, SCANNED: 2, PAID: 3 };

function formatRupiah(value) {
  return `Rp ${Number(value).toLocaleString("id-ID")}`;
}

function getStep() {
  return Number(localStorage.getItem(STEP_KEY) || 0);
}

function setStep(value) {
  localStorage.setItem(STEP_KEY, String(value));
}

function getBooking() {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY) || "null");
  } catch {
    return null;
  }
}

function saveBooking(data) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
}

function setStatus(message, ok = false) {
  if (!globalStatus) return;
  globalStatus.textContent = message;
  globalStatus.classList.toggle("status-banner--ok", ok);
}

function setResult(target, text, ok = false) {
  if (!target) return;
  target.textContent = text;
  target.classList.toggle("result--ok", ok);
  target.classList.toggle("result--warn", !ok);
}

function openModal(message) {
  if (!modal || !modalText) return;
  modalText.textContent = message;
  modal.classList.add("is-open");
  modal.setAttribute("aria-hidden", "false");
}

function closeModal() {
  if (!modal) return;
  modal.classList.remove("is-open");
  modal.setAttribute("aria-hidden", "true");
}

function buildSlots() {
  for (let i = 1; i <= 25; i += 1) {
    const busy = [3, 6, 8, 10, 14, 16, 19, 22, 25].includes(i);
    slotState.push({ id: `A-${i}`, status: busy ? "busy" : "free" });
  }
  const saved = getBooking();
  if (saved?.slot) {
    const locked = slotState.find((item) => item.id === saved.slot && item.status === "free");
    if (locked) locked.status = "busy";
  }
  renderSlots();
}

function renderSlots() {
  if (!slotGrid) return;
  slotGrid.innerHTML = "";

  slotState.forEach((slot) => {
    const button = document.createElement("button");
    button.className = `slot slot--${slot.status}`;
    button.textContent = slot.id;
    button.type = "button";
    button.disabled = slot.status === "busy";
    button.setAttribute("aria-label", `Slot parkir ${slot.id}`);

    button.addEventListener("click", () => {
      if (slot.status === "busy") return;
      slotState.forEach((item) => {
        if (item.status === "picked") item.status = "free";
      });
      slot.status = "picked";
      selectedSlot = slot.id;
      if (selectedSlotEl) selectedSlotEl.textContent = selectedSlot;
      setResult(bookingResult, "Slot dipilih. Lanjut isi detail kendaraan.", true);
      renderSlots();
      syncBookingSummary();
    });

    slotGrid.appendChild(button);
  });
}

function syncBookingSummary() {
  const current = getBooking();
  const sumSlot = document.getElementById("summarySlot");
  const sumPlate = document.getElementById("summaryPlate");
  const sumDuration = document.getElementById("summaryDuration");
  const sumCost = document.getElementById("summaryCost");
  if (!sumSlot) return;

  const slot = selectedSlot || current?.slot || "-";
  const plate = plateInput?.value.trim() || current?.plate || "-";
  const duration = Number(durationInput?.value || current?.duration || 0);
  const vehicle = vehicleType?.value || current?.vehicle || "car";
  const rate = vehicle === "car" ? 3000 : 2000;
  const estimate = duration > 0 ? formatRupiah(duration * rate) : "-";

  sumSlot.textContent = slot;
  sumPlate.textContent = plate || "-";
  sumDuration.textContent = duration > 0 ? `${duration} jam` : "-";
  sumCost.textContent = estimate;
}

function handleBookingConfirm() {
  if (!plateInput || !vehicleType || !durationInput || !bookingResult) return;
  const plate = plateInput.value.trim().toUpperCase();
  const vehicle = vehicleType.value;
  const duration = Number(durationInput.value);

  if (!selectedSlot) return setResult(bookingResult, "Silakan pilih slot terlebih dahulu.");
  if (!plate) return setResult(bookingResult, "Silakan isi nomor plat kendaraan.");
  if (Number.isNaN(duration) || duration < 1 || duration > 8) {
    return setResult(bookingResult, "Durasi harus antara 1 sampai 8 jam.");
  }

  const rate = vehicle === "car" ? 3000 : 2000;
  const deposit = vehicle === "car" ? 5000 : 2000;
  const estimated = rate * duration;
  const total = Math.max(estimated - deposit, 0);
  const qrCode = `BP-${selectedSlot}-${plate.replace(/\s+/g, "").slice(-4)}`;

  const payload = { slot: selectedSlot, plate, vehicle, duration, rate, deposit, estimated, total, qrCode };
  saveBooking(payload);
  setStep(STEPS.BOOKED);

  setResult(
    bookingResult,
    `Booking ${selectedSlot} berhasil. Estimasi ${formatRupiah(estimated)} dan deposit ${formatRupiah(deposit)}.`,
    true,
  );
  setStatus("Booking berhasil. Lanjutkan ke Scan Gerbang untuk aktivasi parkir.", true);

  const chosen = slotState.find((item) => item.id === selectedSlot);
  if (chosen) chosen.status = "busy";
  renderSlots();
  syncBookingSummary();
  openModal(`Kode QR Anda: ${qrCode}. Gunakan saat scan masuk di gerbang.`);
  selectedSlot = null;
  if (selectedSlotEl) selectedSlotEl.textContent = "Belum ada";
}

function setupBookingPage() {
  if (!slotGrid) return;
  buildSlots();
  syncBookingSummary();
  [plateInput, vehicleType, durationInput].forEach((el) => {
    if (el) el.addEventListener("input", syncBookingSummary);
  });
  if (confirmBookingBtn) confirmBookingBtn.addEventListener("click", handleBookingConfirm);
}

function setupScanPage() {
  if (!scanBtn || !scanResult || !parkingStatus || !qrInput) return;
  const booking = getBooking();
  const toPaymentBtn = document.getElementById("toPaymentBtn");
  const scanBookingInfo = document.getElementById("scanBookingInfo");
  const scanHint = document.getElementById("scanHint");

  if (!booking || getStep() < STEPS.BOOKED) {
    setStatus("Belum ada booking aktif. Silakan booking dulu.", false);
    scanBtn.disabled = true;
    if (toPaymentBtn) {
      toPaymentBtn.classList.add("btn--disabled");
      toPaymentBtn.setAttribute("aria-disabled", "true");
      toPaymentBtn.href = "booking.html";
      toPaymentBtn.textContent = "Booking Dulu";
    }
    if (scanHint) scanHint.textContent = "Anda membutuhkan data booking aktif.";
    return;
  }

  if (scanBookingInfo) {
    scanBookingInfo.textContent = `${booking.plate} - Slot ${booking.slot} - Kode ${booking.qrCode}`;
  }
  if (scanHint) scanHint.textContent = `Masukkan kode QR: ${booking.qrCode}`;
  setStatus("Booking terdeteksi. Lanjut scan untuk mengaktifkan sesi parkir.", true);

  scanBtn.addEventListener("click", () => {
    const value = qrInput.value.trim().toUpperCase();
    if (!value) return setResult(scanResult, "Kode QR belum diisi.");
    if (value !== booking.qrCode.toUpperCase()) {
      return setResult(scanResult, "Kode QR tidak sesuai booking.");
    }
    setStep(STEPS.SCANNED);
    setResult(scanResult, `QR valid. Slot ${booking.slot} aktif. Selamat parkir.`, true);
    parkingStatus.textContent = `Parkir aktif untuk ${booking.plate}.`;
    setStatus("Scan berhasil. Anda bisa melanjutkan ke halaman pembayaran.", true);
  });
}

function setupPaymentPage() {
  if (!payNowBtn || !payResult) return;
  const booking = getBooking();
  const billVehicle = document.getElementById("billVehicle");
  const billRate = document.getElementById("billRate");
  const billDeposit = document.getElementById("billDeposit");
  const billTotal = document.getElementById("billTotal");
  const paymentStatusText = document.getElementById("paymentStatusText");
  const toFindBtn = document.getElementById("toFindBtn");

  if (!booking || getStep() < STEPS.SCANNED) {
    setStatus("Pembayaran terkunci. Silakan booking dan scan dulu.", false);
    payNowBtn.disabled = true;
    if (paymentStatusText) paymentStatusText.textContent = "Menunggu scan aktif.";
    if (toFindBtn) {
      toFindBtn.href = "scan.html";
      toFindBtn.textContent = "Ke Scan Gerbang";
    }
    return;
  }

  if (billVehicle) billVehicle.textContent = `Slot ${booking.slot} - ${booking.plate}`;
  if (billRate) billRate.innerHTML = `Tarif Parkir (${booking.duration} jam): <strong>${formatRupiah(booking.estimated)}</strong>`;
  if (billDeposit) billDeposit.innerHTML = `Pengembalian Deposit: <strong>- ${formatRupiah(booking.deposit)}</strong>`;
  if (billTotal) billTotal.innerHTML = `Total Bayar: <strong>${formatRupiah(booking.total)}</strong>`;

  setStatus("Sesi parkir aktif terdeteksi. Lanjutkan pembayaran untuk selesai.", true);

  payNowBtn.addEventListener("click", () => {
    const selected = document.querySelector("input[name='pay']:checked");
    const method = selected ? selected.value.toUpperCase() : "metode";
    setStep(STEPS.PAID);
    setResult(payResult, `Pembayaran berhasil via ${method}.`, true);
    if (paymentStatusText) paymentStatusText.textContent = "Lunas. Anda dapat melihat lokasi kendaraan.";
    setStatus("Pembayaran berhasil. Lanjut ke Find Vehicle.", true);
  });
}

function setupFindVehiclePage() {
  if (!navBtn || !navResult) return;
  const booking = getBooking();
  const vehicleLocationText = document.getElementById("vehicleLocationText");
  const vehicleStatusText = document.getElementById("vehicleStatusText");
  const distanceText = document.getElementById("distanceText");
  const directionSteps = document.getElementById("directionSteps");

  if (!booking || getStep() < STEPS.PAID) {
    navBtn.disabled = true;
    setStatus("Akses dibatasi. Selesaikan pembayaran terlebih dahulu.", false);
    if (vehicleStatusText) vehicleStatusText.textContent = "Belum ditemukan";
    return;
  }

  if (vehicleLocationText) {
    vehicleLocationText.textContent = `${booking.plate} berada di Slot ${booking.slot}, Zona A, Lantai 1.`;
  }
  if (vehicleStatusText) vehicleStatusText.innerHTML = `${booking.plate} - <strong>Ditemukan</strong>`;
  if (distanceText) distanceText.innerHTML = "Jarak: <strong>42m</strong> | Estimasi: <strong>1 menit</strong>";
  if (directionSteps) {
    directionSteps.innerHTML = `
      <li>Masuk dari gerbang utama.</li>
      <li>Ambil jalur kiri menuju Zona A.</li>
      <li>Ikuti marka lantai hingga Slot ${booking.slot}.</li>
    `;
  }
  setStatus("Semua proses selesai. Navigasi kendaraan siap digunakan.", true);

  navBtn.addEventListener("click", () => {
    setResult(navResult, `Navigasi aktif ke ${booking.slot}. Ikuti petunjuk arah di layar.`, true);
  });
}

if (menuToggle && menu) {
  menuToggle.addEventListener("click", () => menu.classList.toggle("is-open"));
}

if (closeModalBtn) closeModalBtn.addEventListener("click", closeModal);
if (modal) {
  modal.addEventListener("click", (event) => {
    if (event.target === modal) closeModal();
  });
}

const yearEl = document.getElementById("year");
if (yearEl) yearEl.textContent = new Date().getFullYear();

setupBookingPage();
setupScanPage();
setupPaymentPage();
setupFindVehiclePage();
