import os


def replace_in_file(path: str, mapping: dict[str, str]) -> None:
    with open(path, "r", encoding="utf-8") as f:
        content = f.read()

    original = content
    for remote, local in mapping.items():
        content = content.replace(remote, local)

    if content != original:
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)
        print(f"Updated: {os.path.basename(path)}")
    else:
        print(f"No changes: {os.path.basename(path)}")


def main() -> None:
    root = os.path.dirname(os.path.abspath(__file__))
    html_files = [
        "index.html",
        "booking.html",
        "scan.html",
        "pembayaran.html",
        "find-vehicle.html",
    ]

    mapping = {
        "https://cdn-icons-png.flaticon.com/512/3097/3097144.png": "assets/icons/logo-beepark.png",
        "https://cdn-icons-png.flaticon.com/512/2972/2972185.png": "assets/icons/icon-qr.png",
        "https://cdn-icons-png.flaticon.com/512/854/854878.png": "assets/icons/icon-map-pin.png",
        "https://cdn-icons-png.flaticon.com/512/1792/1792688.png": "assets/icons/icon-wallet.png",
        "https://cdn-icons-png.flaticon.com/512/3202/3202926.png": "assets/icons/icon-parking.png",
        "https://cdn-icons-png.flaticon.com/512/535/535188.png": "assets/icons/icon-location-pin.png",
        "https://cdn-icons-png.flaticon.com/512/565/565547.png": "assets/icons/icon-payment.png",
        "https://cdn-icons-png.flaticon.com/512/2550/2550205.png": "assets/icons/icon-qr-scan.png",
        "https://images.unsplash.com/photo-1519583272095-6433daf26b6e?auto=format&fit=crop&w=1000&q=80": "assets/images/hero-parking.jpg",
        "https://images.unsplash.com/photo-1519583272095-6433daf26b6e?auto=format&fit=crop&w=1200&q=80": "assets/images/hero-parking.jpg",
        "https://images.unsplash.com/photo-1621929747188-0b4dc28498d2?auto=format&fit=crop&w=800&q=80": "assets/images/parking-gate.jpg",
        "https://images.pexels.com/photos/4386321/pexels-photo-4386321.jpeg?auto=compress&cs=tinysrgb&w=900": "assets/images/find-vehicle-map.jpg",
        "https://images.pexels.com/photos/1004409/pexels-photo-1004409.jpeg?auto=compress&cs=tinysrgb&w=600": "assets/images/parking-photo.jpg",
        "https://i.pinimg.com/564x/7b/37/8a/7b378a4fef35a531fcb021adf50f4c2f.jpg": "assets/images/pinterest-ui.jpg",
    }

    for name in html_files:
        replace_in_file(os.path.join(root, name), mapping)

    print("\nDone. Local assets are now referenced in HTML files.")


if __name__ == "__main__":
    main()
