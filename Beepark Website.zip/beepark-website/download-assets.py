import os
import urllib.request


def main() -> None:
    root = os.path.dirname(os.path.abspath(__file__))
    assets_root = os.path.join(root, "assets")
    icons_dir = os.path.join(assets_root, "icons")
    images_dir = os.path.join(assets_root, "images")
    os.makedirs(icons_dir, exist_ok=True)
    os.makedirs(images_dir, exist_ok=True)

    # Real assets (non-AI) from Flaticon, Unsplash, Pinterest, and Pexels.
    files = {
        "icons/logo-beepark.png": "https://cdn-icons-png.flaticon.com/512/3097/3097144.png",
        "icons/icon-qr.png": "https://cdn-icons-png.flaticon.com/512/2972/2972185.png",
        "icons/icon-map-pin.png": "https://cdn-icons-png.flaticon.com/512/854/854878.png",
        "icons/icon-wallet.png": "https://cdn-icons-png.flaticon.com/512/1792/1792688.png",
        "icons/icon-parking.png": "https://cdn-icons-png.flaticon.com/512/3202/3202926.png",
        "icons/icon-location-pin.png": "https://cdn-icons-png.flaticon.com/512/535/535188.png",
        "icons/icon-payment.png": "https://cdn-icons-png.flaticon.com/512/565/565547.png",
        "icons/icon-qr-scan.png": "https://cdn-icons-png.flaticon.com/512/2550/2550205.png",
        "images/hero-parking.jpg": "https://images.unsplash.com/photo-1519583272095-6433daf26b6e?auto=format&fit=crop&w=1400&q=80",
        "images/parking-gate.jpg": "https://images.unsplash.com/photo-1621929747188-0b4dc28498d2?auto=format&fit=crop&w=1200&q=80",
        "images/find-vehicle-map.jpg": "https://images.pexels.com/photos/4386321/pexels-photo-4386321.jpeg?auto=compress&cs=tinysrgb&w=1200",
        "images/pinterest-ui.jpg": "https://i.pinimg.com/564x/7b/37/8a/7b378a4fef35a531fcb021adf50f4c2f.jpg",
        "images/parking-photo.jpg": "https://images.pexels.com/photos/1004409/pexels-photo-1004409.jpeg?auto=compress&cs=tinysrgb&w=1200",
    }

    for rel_path, url in files.items():
        out = os.path.join(assets_root, rel_path)
        print(f"Downloading {rel_path} ...")
        urllib.request.urlretrieve(url, out)

    print("\nAll assets downloaded successfully.")
    print(f"Location: {assets_root}")


if __name__ == "__main__":
    main()
